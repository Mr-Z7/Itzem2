export type Listing = {
  id: string
  title: string
  price: number
  category: string
  subcategory: string
  location: string
  city: string
  description: string
  images: string[]
  seller: {
    name: string
    phone: string
    whatsapp: string
    memberSince: string
    verified: boolean
    avatar: string
    totalAds: number
  }
  postedAt: string
  featured: boolean
  condition: 'New' | 'Like New' | 'Good' | 'Fair'
  views: number
}

export type Category = {
  id: string
  name: string
  icon: string
  count: number
  color: string
}

export const categories: Category[] = [
  { id: 'vehicles', name: 'Vehicles', icon: '🚗', count: 4821, color: 'from-blue-500 to-blue-600' },
  { id: 'mobiles', name: 'Mobiles', icon: '📱', count: 6302, color: 'from-purple-500 to-purple-600' },
  { id: 'property', name: 'Property', icon: '🏠', count: 3145, color: 'from-green-500 to-green-600' },
  { id: 'electronics', name: 'Electronics', icon: '💻', count: 5678, color: 'from-orange-500 to-orange-600' },
  { id: 'fashion', name: 'Fashion', icon: '👗', count: 2890, color: 'from-pink-500 to-pink-600' },
  { id: 'furniture', name: 'Furniture', icon: '🛋️', count: 1923, color: 'from-yellow-500 to-yellow-600' },
  { id: 'jobs', name: 'Jobs', icon: '💼', count: 3410, color: 'from-teal-500 to-teal-600' },
  { id: 'animals', name: 'Animals', icon: '🐾', count: 876, color: 'from-red-500 to-red-600' },
]

export const listings: Listing[] = [
  {
    id: '1',
    title: 'Toyota Corolla 2020 – Immaculate Condition, Full Option',
    price: 5850000,
    category: 'vehicles',
    subcategory: 'Cars',
    location: 'DHA Phase 6',
    city: 'Lahore',
    description: `Selling my Toyota Corolla Altis X 2020 in absolutely showroom condition. Never been in any accident. All original paint with ceramic coating done last month. Mileage is only 28,000 km — mostly highway driven.

Features include:
- 1800cc engine, automatic transmission
- Push start, keyless entry
- Leather seats, sunroof
- Reverse camera + parking sensors
- Android Auto / Apple CarPlay
- Original factory alloy wheels

All documents are clear — registration, original file, road tax paid. Serious buyers only, no wasters please. Test drive available in DHA only.`,
    images: [
      'https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?w=800&q=80',
      'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=800&q=80',
      'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?w=800&q=80',
    ],
    seller: {
      name: 'Usman Tariq',
      phone: '0300-1234567',
      whatsapp: '923001234567',
      memberSince: 'Jan 2021',
      verified: true,
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&q=80',
      totalAds: 3,
    },
    postedAt: '2 hours ago',
    featured: true,
    condition: 'Like New',
    views: 1420,
  },
  {
    id: '2',
    title: 'iPhone 15 Pro Max – 256GB Natural Titanium, PTA Approved',
    price: 389000,
    category: 'mobiles',
    subcategory: 'Smartphones',
    location: 'Gulshan-e-Iqbal',
    city: 'Karachi',
    description: `Selling my iPhone 15 Pro Max 256GB in Natural Titanium color. PTA approved, 10 months old with all original accessories.

Box includes:
- iPhone 15 Pro Max
- Original charger cable (USB-C)
- Original box & documentation
- 2 screen protectors (applied one, spare packed)

Battery health: 96%. No scratches on screen or body. Used with a case since day one. Face ID works perfectly. Reason for selling: upgrading to 16 Pro Max.`,
    images: [
      'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800&q=80',
      'https://images.unsplash.com/photo-1591337676887-a217a6970a8a?w=800&q=80',
    ],
    seller: {
      name: 'Ayesha Raza',
      phone: '0321-9876543',
      whatsapp: '923219876543',
      memberSince: 'Mar 2022',
      verified: true,
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&q=80',
      totalAds: 8,
    },
    postedAt: '5 hours ago',
    featured: true,
    condition: 'Like New',
    views: 983,
  },
  {
    id: '3',
    title: '5 Marla House for Sale – Prime Location, F-10 Islamabad',
    price: 28500000,
    category: 'property',
    subcategory: 'Houses',
    location: 'F-10/2',
    city: 'Islamabad',
    description: `Beautiful 5 Marla double-storey house for sale in one of the best sectors of Islamabad. Fully renovated in 2023 with high-end finishes.

Ground Floor: Lounge, dining, kitchen, 1 bedroom with attached bath, servant quarter.
First Floor: 3 bedrooms, 2 attached baths, drawing room, balcony.

Features: Marble flooring, modular kitchen, American standard fittings, 3 ACs, 2 geysers, UPS setup, car porch for 2 cars, back lane access, gas + electricity.

Price is slightly negotiable for serious buyers. No agents please.`,
    images: [
      'https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=800&q=80',
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=80',
      'https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?w=800&q=80',
    ],
    seller: {
      name: 'Asif Mahmood',
      phone: '0345-5552233',
      whatsapp: '923455552233',
      memberSince: 'Sep 2019',
      verified: true,
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&q=80',
      totalAds: 5,
    },
    postedAt: '1 day ago',
    featured: true,
    condition: 'Good',
    views: 2841,
  },
  {
    id: '4',
    title: 'Dell XPS 15 Laptop – Core i9, 32GB RAM, RTX 4060',
    price: 425000,
    category: 'electronics',
    subcategory: 'Laptops',
    location: 'Saddar',
    city: 'Rawalpindi',
    description: `Selling Dell XPS 15 9530 (2023 model) — the best Windows laptop money can buy. Used for 8 months, always handled with care.

Specs:
- Intel Core i9-13900H (2.6GHz, 24 cores)
- 32GB DDR5 RAM
- 1TB NVMe SSD
- NVIDIA RTX 4060 8GB
- 15.6" OLED 3.5K 120Hz display
- Windows 11 Pro, Office 2021

Battery holds 5+ hours on moderate usage. No dead pixels, keyboard perfect. Thermal pads renewed. Comes with original charger and box.`,
    images: [
      'https://images.unsplash.com/photo-1593642632559-0c6d3fc62b89?w=800&q=80',
      'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=800&q=80',
    ],
    seller: {
      name: 'Bilal Hassan',
      phone: '0333-4441122',
      whatsapp: '923334441122',
      memberSince: 'Jul 2020',
      verified: false,
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&q=80',
      totalAds: 12,
    },
    postedAt: '3 hours ago',
    featured: false,
    condition: 'Good',
    views: 671,
  },
  {
    id: '5',
    title: 'Honda CD 70 2023 – Brand New Condition, 2,000 km',
    price: 155000,
    category: 'vehicles',
    subcategory: 'Motorcycles',
    location: 'Johar Town',
    city: 'Lahore',
    description: `Honda CD 70 2023 model — barely used, like brand new. Only 2,000 km driven. All documents complete.

- Original company paint (Black)
- No scratches or dents
- All papers clear
- Registration in seller's name
- Original toolkit included

Reason for sale: Bought a car so don't need anymore. Price is final — 1.55 lac only. Call between 10am–8pm.`,
    images: [
      'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80',
      'https://images.unsplash.com/photo-1568772585407-9361f9bf3a87?w=800&q=80',
    ],
    seller: {
      name: 'Kamran Ali',
      phone: '0311-7778899',
      whatsapp: '923117778899',
      memberSince: 'Apr 2023',
      verified: false,
      avatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=100&q=80',
      totalAds: 1,
    },
    postedAt: '6 hours ago',
    featured: false,
    condition: 'Like New',
    views: 389,
  },
  {
    id: '6',
    title: 'Samsung 65" QLED 4K Smart TV – QN90B Series',
    price: 285000,
    category: 'electronics',
    subcategory: 'TVs',
    location: 'Clifton',
    city: 'Karachi',
    description: `Samsung 65-inch QN90B Neo QLED 4K Smart TV — 1 year old, bought from Samsung authorized dealer. Invoice available.

Features:
- Neo QLED with Quantum Matrix Technology
- 4K 120Hz panel (perfect for gaming/sports)
- Dolby Atmos, built-in Alexa
- 4 HDMI ports, 2 USB ports
- Samsung Gaming Hub (no console needed)

No burn-in, panel in perfect condition. Selling because relocating abroad. Original remote, wall mount bracket included.`,
    images: [
      'https://images.unsplash.com/photo-1593359677879-a4bb92f829e1?w=800&q=80',
      'https://images.unsplash.com/photo-1461151304267-38535e780c79?w=800&q=80',
    ],
    seller: {
      name: 'Sara Khwaja',
      phone: '0312-5566778',
      whatsapp: '923125566778',
      memberSince: 'Feb 2021',
      verified: true,
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&q=80',
      totalAds: 4,
    },
    postedAt: '12 hours ago',
    featured: true,
    condition: 'Good',
    views: 512,
  },
  {
    id: '7',
    title: 'Wooden Sofa Set – L-Shape 7 Seater, Luxury Fabric',
    price: 95000,
    category: 'furniture',
    subcategory: 'Sofas',
    location: 'Model Town',
    city: 'Lahore',
    description: `Beautiful L-shape 7-seater sofa set in premium fabric. Bought 2 years ago for 1.6 lac from a well-known furniture shop. Moving to a smaller place, hence selling.

Material: Solid sheesham wood frame with premium Belgian fabric
Size: L-shape fits up to 10x12 room comfortably
Color: Warm grey (as shown in photo)
Condition: 8/10 — minor wear on armrests, no tears or stains

Self-pickup only from Model Town. No delivery. Call after 6pm.`,
    images: [
      'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=800&q=80',
      'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=800&q=80',
    ],
    seller: {
      name: 'Nadia Qureshi',
      phone: '0301-3344556',
      whatsapp: '923013344556',
      memberSince: 'Jun 2022',
      verified: false,
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&q=80',
      totalAds: 2,
    },
    postedAt: '2 days ago',
    featured: false,
    condition: 'Good',
    views: 234,
  },
  {
    id: '8',
    title: 'Software Engineer – Remote Job, PKR 150K–250K/month',
    price: 0,
    category: 'jobs',
    subcategory: 'IT & Software',
    location: 'Remote (Work From Home)',
    city: 'Islamabad',
    description: `Tech startup seeking a skilled Software Engineer to join our growing team remotely.

Requirements:
- 2+ years experience in React, Node.js
- TypeScript knowledge preferred
- Experience with REST APIs and databases (MongoDB/PostgreSQL)
- Good communication skills in English

We offer:
- Competitive salary PKR 150K–250K based on experience
- Remote work (5 days/week)
- Medical insurance
- Annual performance bonus
- Friendly startup culture

Send your CV on WhatsApp with "SE Application" in the message.`,
    images: [
      'https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?w=800&q=80',
    ],
    seller: {
      name: 'TechPak Solutions',
      phone: '0342-1010101',
      whatsapp: '923421010101',
      memberSince: 'Nov 2020',
      verified: true,
      avatar: 'https://images.unsplash.com/photo-1560179707-f14e90ef3623?w=100&q=80',
      totalAds: 18,
    },
    postedAt: '4 hours ago',
    featured: true,
    condition: 'New',
    views: 1102,
  },
  {
    id: '9',
    title: 'Husky Puppy – Pure Breed, 2 Months Old, Vaccinated',
    price: 35000,
    category: 'animals',
    subcategory: 'Dogs',
    location: 'Bahria Town',
    city: 'Rawalpindi',
    description: `Beautiful Siberian Husky puppy — pure breed, 2 months old. Both parents on premises, can be shown. First vaccination done, vet card available.

- Blue eyes, grey/white coat
- Very friendly and playful
- Eating well (kibble + homemade food)
- Dewormed twice
- Ready to go to a loving home

Serious pet lovers only. Please don't contact if you can't provide proper care and space.`,
    images: [
      'https://images.unsplash.com/photo-1605568427561-40dd23c2acea?w=800&q=80',
      'https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=800&q=80',
    ],
    seller: {
      name: 'Zara Siddiqui',
      phone: '0314-9988776',
      whatsapp: '923149988776',
      memberSince: 'Aug 2023',
      verified: false,
      avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=100&q=80',
      totalAds: 2,
    },
    postedAt: '1 day ago',
    featured: false,
    condition: 'New',
    views: 743,
  },
  {
    id: '10',
    title: 'Gents Leather Jacket – Genuine Leather, XL Size',
    price: 18500,
    category: 'fashion',
    subcategory: 'Clothing',
    location: 'G-11',
    city: 'Islamabad',
    description: `Premium genuine leather jacket, bought from Lahore's Liberty market for 32,000. Worn only 4-5 times. Pure lamb leather, very soft.

Size: XL (fits 42–44 chest)
Color: Dark brown
Lining: Full silk lining
YKK zippers throughout

Perfect for winter. Dry-cleaned before listing. No repairs or damage. Selling due to weight gain — the jacket no longer fits me.`,
    images: [
      'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=800&q=80',
    ],
    seller: {
      name: 'Hamza Sheikh',
      phone: '0322-6677889',
      whatsapp: '923226677889',
      memberSince: 'Jan 2024',
      verified: false,
      avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&q=80',
      totalAds: 1,
    },
    postedAt: '3 days ago',
    featured: false,
    condition: 'Like New',
    views: 156,
  },
  {
    id: '11',
    title: 'Honda Civic 2022 Oriel CVT – Black, 22,000 km',
    price: 7200000,
    category: 'vehicles',
    subcategory: 'Cars',
    location: 'Gulberg III',
    city: 'Lahore',
    description: `Honda Civic 11th Gen 2022 Oriel CVT in Meteoroid Gray. One owner since new. Full Honda service history.

- 1498cc VTEC Turbo, CVT automatic
- Honda Sensing active safety suite
- LED headlights & taillights
- Wireless Apple CarPlay/Android Auto
- Heated front seats
- 12-inch Honda Connect infotainment

22,000 km on odo (all genuine). No accidents, original paint. Tyres 80% life. Price final — not accepting agents.`,
    images: [
      'https://images.unsplash.com/photo-1609521263047-f8f205293f24?w=800&q=80',
      'https://images.unsplash.com/photo-1580273916550-e323be2ae537?w=800&q=80',
    ],
    seller: {
      name: 'Rizwan Baig',
      phone: '0300-8899001',
      whatsapp: '923008899001',
      memberSince: 'Oct 2018',
      verified: true,
      avatar: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=100&q=80',
      totalAds: 7,
    },
    postedAt: '5 hours ago',
    featured: true,
    condition: 'Like New',
    views: 1876,
  },
  {
    id: '12',
    title: 'Samsung Galaxy S24 Ultra – 512GB Titanium Violet, Brand New',
    price: 365000,
    category: 'mobiles',
    subcategory: 'Smartphones',
    location: 'Defence',
    city: 'Karachi',
    description: `Brand new, sealed box Samsung Galaxy S24 Ultra 512GB in Titanium Violet. PTA approved, brought from Dubai duty-free.

In the box: Phone, S Pen, USB-C cable, warranty card (global).
Global warranty valid for 1 year.

Will show opening on video call if needed. Cash on delivery available within Karachi only (COD charges extra). Price is fixed, no bargaining.`,
    images: [
      'https://images.unsplash.com/photo-1706900049399-93f174d34356?w=800&q=80',
      'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=800&q=80',
    ],
    seller: {
      name: 'Farhan Mirza',
      phone: '0317-2233445',
      whatsapp: '923172233445',
      memberSince: 'May 2022',
      verified: true,
      avatar: 'https://images.unsplash.com/photo-1463453091185-61582044d556?w=100&q=80',
      totalAds: 21,
    },
    postedAt: '8 hours ago',
    featured: false,
    condition: 'New',
    views: 892,
  },
]

export const formatPrice = (price: number): string => {
  if (price === 0) return 'Contact for Salary'
  if (price >= 10000000) return `PKR ${(price / 10000000).toFixed(1)} Crore`
  if (price >= 100000) return `PKR ${(price / 100000).toFixed(1)} Lakh`
  if (price >= 1000) return `PKR ${(price / 1000).toFixed(0)}K`
  return `PKR ${price.toLocaleString()}`
}

export const cities = ['All Cities', 'Karachi', 'Lahore', 'Islamabad', 'Rawalpindi', 'Peshawar', 'Multan', 'Faisalabad', 'Quetta']
