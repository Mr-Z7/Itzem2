'use client'
import { useState } from 'react'
import Link from 'next/link'
import { Search, Menu, X, Bell, ChevronDown, MapPin, Plus } from 'lucide-react'

export default function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-ink-100 shadow-sm">
      {/* Top bar */}
      <div className="bg-ink-900 text-ink-300 text-xs py-1.5 px-4 text-center font-jakarta hidden md:block">
        🇵🇰 Pakistan's most trusted marketplace — Verified sellers, safe transactions
      </div>

      {/* Main nav */}
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">

          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 shrink-0">
            <div className="w-8 h-8 rounded-lg bg-brand-500 flex items-center justify-center">
              <span className="text-white font-sora font-bold text-sm">iz</span>
            </div>
            <span className="font-sora font-bold text-xl text-ink-900 tracking-tight">
              itz<span className="text-brand-500">em</span>
            </span>
          </Link>

          {/* Search bar (desktop) */}
          <div className="hidden md:flex flex-1 max-w-2xl items-center bg-ink-50 border border-ink-200 rounded-xl overflow-hidden hover:border-brand-400 transition-colors focus-within:border-brand-500 focus-within:ring-2 focus-within:ring-brand-100">
            <button className="flex items-center gap-1 px-3 py-2.5 text-sm text-ink-500 border-r border-ink-200 hover:bg-ink-100 whitespace-nowrap shrink-0">
              <MapPin size={14} className="text-brand-500" />
              All Pakistan
              <ChevronDown size={12} />
            </button>
            <input
              type="text"
              placeholder="What are you looking for?"
              className="flex-1 px-4 py-2.5 bg-transparent text-sm text-ink-800 placeholder-ink-400 outline-none font-jakarta"
            />
            <button className="m-1 bg-brand-500 hover:bg-brand-600 text-white px-4 py-2 rounded-lg transition-colors">
              <Search size={16} />
            </button>
          </div>

          {/* Right actions */}
          <div className="flex items-center gap-2 shrink-0">
            <button className="hidden md:flex items-center gap-1.5 text-ink-600 hover:text-ink-900 p-2 rounded-lg hover:bg-ink-50 transition-colors relative">
              <Bell size={18} />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-brand-500 rounded-full"></span>
            </button>
            <Link
              href="/listings"
              className="hidden md:block text-sm font-medium text-ink-700 hover:text-ink-900 px-3 py-2 rounded-lg hover:bg-ink-50 transition-colors"
            >
              Browse
            </Link>
            <Link
              href="#"
              className="flex items-center gap-1.5 bg-brand-500 hover:bg-brand-600 text-white text-sm font-semibold px-4 py-2 rounded-xl transition-all shadow-sm hover:shadow-brand-glow"
            >
              <Plus size={15} strokeWidth={2.5} />
              <span className="hidden sm:inline">Post Ad</span>
            </Link>

            {/* Mobile hamburger */}
            <button
              className="md:hidden p-2 rounded-lg hover:bg-ink-50 text-ink-700"
              onClick={() => setMobileOpen(!mobileOpen)}
            >
              {mobileOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>

        {/* Mobile search */}
        <div className="md:hidden pb-3">
          <div className="flex items-center bg-ink-50 border border-ink-200 rounded-xl overflow-hidden">
            <input
              type="text"
              placeholder="Search anything..."
              className="flex-1 px-4 py-2.5 bg-transparent text-sm outline-none font-jakarta text-ink-800 placeholder-ink-400"
            />
            <button className="m-1 bg-brand-500 text-white px-3 py-2 rounded-lg">
              <Search size={15} />
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="md:hidden bg-white border-t border-ink-100 px-4 py-4 space-y-1">
          {['Browse Ads', 'Categories', 'My Ads', 'Login / Register'].map((item) => (
            <Link
              key={item}
              href={item === 'Browse Ads' ? '/listings' : '#'}
              className="block px-4 py-3 rounded-xl text-sm font-medium text-ink-700 hover:bg-ink-50 hover:text-ink-900 transition-colors"
              onClick={() => setMobileOpen(false)}
            >
              {item}
            </Link>
          ))}
        </div>
      )}
    </header>
  )
}
