import Link from 'next/link'

export default function Footer() {
  return (
    <footer className="bg-ink-900 text-ink-300 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-10">
          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-brand-500 flex items-center justify-center">
                <span className="text-white font-sora font-bold text-sm">iz</span>
              </div>
              <span className="font-sora font-bold text-xl text-white">
                itz<span className="text-brand-400">em</span>
              </span>
            </div>
            <p className="text-sm leading-relaxed text-ink-400 max-w-xs">
              Pakistan's trusted platform to buy and sell anything — from cars to mobiles, property to fashion.
            </p>
            <div className="flex gap-3 mt-4">
              {['📱', '💻', '🌐'].map((icon, i) => (
                <button key={i} className="w-8 h-8 bg-ink-800 rounded-lg flex items-center justify-center text-sm hover:bg-brand-500 transition-colors">
                  {icon}
                </button>
              ))}
            </div>
          </div>

          {/* Categories */}
          <div>
            <h4 className="font-sora font-semibold text-white mb-4 text-sm">Categories</h4>
            <ul className="space-y-2">
              {['Vehicles', 'Mobiles', 'Property', 'Electronics', 'Fashion', 'Furniture'].map(cat => (
                <li key={cat}>
                  <Link href="/listings" className="text-sm hover:text-brand-400 transition-colors">{cat}</Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Cities */}
          <div>
            <h4 className="font-sora font-semibold text-white mb-4 text-sm">Top Cities</h4>
            <ul className="space-y-2">
              {['Karachi', 'Lahore', 'Islamabad', 'Rawalpindi', 'Peshawar', 'Multan'].map(city => (
                <li key={city}>
                  <Link href="/listings" className="text-sm hover:text-brand-400 transition-colors">{city}</Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Help */}
          <div>
            <h4 className="font-sora font-semibold text-white mb-4 text-sm">Help & Info</h4>
            <ul className="space-y-2">
              {['About Itzem', 'Safety Tips', 'Contact Us', 'Privacy Policy', 'Terms of Use', 'Post an Ad'].map(link => (
                <li key={link}>
                  <Link href="#" className="text-sm hover:text-brand-400 transition-colors">{link}</Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="border-t border-ink-800 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-ink-500">© 2024 Itzem. All rights reserved. Made with ❤️ in Pakistan.</p>
          <div className="flex gap-4 text-xs text-ink-500">
            <Link href="#" className="hover:text-brand-400 transition-colors">Privacy</Link>
            <Link href="#" className="hover:text-brand-400 transition-colors">Terms</Link>
            <Link href="#" className="hover:text-brand-400 transition-colors">Cookies</Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
