import Link from 'next/link'
import Image from 'next/image'
import { MapPin, Eye, Heart, Star } from 'lucide-react'
import { Listing, formatPrice } from '@/lib/mockData'

export default function ListingCard({ listing }: { listing: Listing }) {
  const conditionColor: Record<string, string> = {
    'New': 'bg-green-100 text-green-700',
    'Like New': 'bg-blue-100 text-blue-700',
    'Good': 'bg-yellow-100 text-yellow-700',
    'Fair': 'bg-orange-100 text-orange-700',
  }

  return (
    <Link href={`/listings/${listing.id}`}>
      <article className="listing-card bg-white rounded-2xl overflow-hidden shadow-card cursor-pointer group">
        {/* Image */}
        <div className="relative aspect-[4/3] overflow-hidden image-zoom bg-ink-100">
          <Image
            src={listing.images[0]}
            alt={listing.title}
            fill
            className="object-cover"
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
          />

          {/* Overlays */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

          {listing.featured && (
            <div className="absolute top-3 left-3 badge-featured text-white text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wide shadow">
              ⭐ Featured
            </div>
          )}

          <button className="absolute top-3 right-3 w-8 h-8 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center text-ink-400 hover:text-red-500 transition-colors shadow">
            <Heart size={14} />
          </button>

          {listing.images.length > 1 && (
            <div className="absolute bottom-2 right-2 bg-black/50 text-white text-[10px] px-1.5 py-0.5 rounded-md backdrop-blur-sm">
              +{listing.images.length - 1} photos
            </div>
          )}
        </div>

        {/* Content */}
        <div className="p-4">
          {/* Price */}
          <div className="flex items-start justify-between gap-2 mb-2">
            <p className="font-sora font-bold text-lg price-tag leading-tight">
              {formatPrice(listing.price)}
            </p>
            <span className={`shrink-0 text-[10px] font-semibold px-2 py-0.5 rounded-full ${conditionColor[listing.condition]}`}>
              {listing.condition}
            </span>
          </div>

          {/* Title */}
          <h3 className="font-jakarta font-semibold text-sm text-ink-800 line-clamp-2 leading-snug mb-3">
            {listing.title}
          </h3>

          {/* Footer */}
          <div className="flex items-center justify-between pt-3 border-t border-ink-100">
            <div className="flex items-center gap-1 text-ink-400">
              <MapPin size={12} />
              <span className="text-xs font-medium">{listing.city}</span>
            </div>
            <div className="flex items-center gap-3 text-ink-400">
              <span className="flex items-center gap-1 text-xs">
                <Eye size={12} />
                {listing.views.toLocaleString()}
              </span>
              <span className="text-xs text-ink-300">{listing.postedAt}</span>
            </div>
          </div>
        </div>
      </article>
    </Link>
  )
}
