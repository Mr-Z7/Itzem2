'use client'
import { useState } from 'react'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import Image from 'next/image'
import {
  MapPin, Eye, Clock, Shield, ChevronLeft, Heart,
  Share2, Phone, MessageCircle, CheckCircle, Star,
  ChevronRight, Flag, ArrowRight,
} from 'lucide-react'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import ListingCard from '@/components/ListingCard'
import { listings, formatPrice } from '@/lib/mockData'

export default function AdDetailPage({ params }: { params: { id: string } }) {
  const listing = listings.find(l => l.id === params.id)
  if (!listing) notFound()

  const related = listings.filter(l => l.category === listing.category && l.id !== listing.id).slice(0, 4)

  return (
    <AdDetailClient listing={listing} related={related} />
  )
}

function AdDetailClient({ listing, related }: { listing: any, related: any[] }) {
  const [activeImage, setActiveImage] = useState(0)
  const [saved, setSaved] = useState(false)

  const conditionColor: Record<string, string> = {
    'New': 'bg-green-100 text-green-700 border-green-200',
    'Like New': 'bg-blue-100 text-blue-700 border-blue-200',
    'Good': 'bg-yellow-100 text-yellow-700 border-yellow-200',
    'Fair': 'bg-orange-100 text-orange-700 border-orange-200',
  }

  return (
    <main>
      <Navbar />

      {/* ─── BREADCRUMB ─── */}
      <div className="bg-white border-b border-ink-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <nav className="flex items-center gap-2 text-xs text-ink-400 font-jakarta">
            <Link href="/" className="hover:text-brand-500 transition-colors">Home</Link>
            <ChevronRight size={12} />
            <Link href="/listings" className="hover:text-brand-500 transition-colors">Listings</Link>
            <ChevronRight size={12} />
            <span className="text-ink-600 truncate max-w-[200px]">{listing.title}</span>
          </nav>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">

          {/* ─── LEFT COLUMN ─── */}
          <div className="lg:col-span-2 space-y-6">

            {/* ─── IMAGES ─── */}
            <div className="bg-white rounded-2xl overflow-hidden shadow-card">
              {/* Main image */}
              <div className="relative aspect-[16/10] bg-ink-100 overflow-hidden">
                <Image
                  src={listing.images[activeImage]}
                  alt={listing.title}
                  fill
                  className="object-cover transition-all duration-300"
                  priority
                  sizes="(max-width: 1024px) 100vw, 66vw"
                />

                {listing.featured && (
                  <div className="absolute top-4 left-4 badge-featured text-white text-xs font-bold px-3 py-1 rounded-full shadow-lg">
                    ⭐ Featured Ad
                  </div>
                )}

                {/* Nav arrows */}
                {listing.images.length > 1 && (
                  <>
                    <button
                      onClick={() => setActiveImage(i => Math.max(0, i - 1))}
                      className="absolute left-3 top-1/2 -translate-y-1/2 w-9 h-9 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center shadow-md hover:bg-white transition-colors disabled:opacity-40"
                      disabled={activeImage === 0}
                    >
                      <ChevronLeft size={18} className="text-ink-700" />
                    </button>
                    <button
                      onClick={() => setActiveImage(i => Math.min(listing.images.length - 1, i + 1))}
                      className="absolute right-3 top-1/2 -translate-y-1/2 w-9 h-9 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center shadow-md hover:bg-white transition-colors disabled:opacity-40"
                      disabled={activeImage === listing.images.length - 1}
                    >
                      <ChevronRight size={18} className="text-ink-700" />
                    </button>
                  </>
                )}
              </div>

              {/* Thumbnails */}
              {listing.images.length > 1 && (
                <div className="flex gap-2 p-3 bg-ink-50 border-t border-ink-100">
                  {listing.images.map((img: string, i: number) => (
                    <button
                      key={i}
                      onClick={() => setActiveImage(i)}
                      className={`relative w-16 h-12 rounded-lg overflow-hidden flex-shrink-0 border-2 transition-all ${activeImage === i ? 'border-brand-500 shadow-sm' : 'border-transparent opacity-70 hover:opacity-100'}`}
                    >
                      <Image src={img} alt="" fill className="object-cover" sizes="64px" />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* ─── TITLE & PRICE ─── */}
            <div className="bg-white rounded-2xl shadow-card p-6">
              <div className="flex items-start justify-between gap-4 mb-4">
                <div className="flex-1">
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    <span className={`text-xs font-semibold px-2.5 py-0.5 rounded-full border ${conditionColor[listing.condition]}`}>
                      {listing.condition}
                    </span>
                    <span className="text-xs text-ink-400 bg-ink-100 px-2.5 py-0.5 rounded-full">
                      {listing.subcategory}
                    </span>
                  </div>
                  <h1 className="font-sora font-bold text-xl md:text-2xl text-ink-900 leading-tight">
                    {listing.title}
                  </h1>
                </div>
                <div className="flex gap-2 shrink-0">
                  <button
                    onClick={() => setSaved(!saved)}
                    className={`w-10 h-10 rounded-xl border flex items-center justify-center transition-all ${saved ? 'border-red-300 bg-red-50 text-red-500' : 'border-ink-200 text-ink-400 hover:border-red-300 hover:text-red-400'}`}
                  >
                    <Heart size={16} fill={saved ? 'currentColor' : 'none'} />
                  </button>
                  <button className="w-10 h-10 rounded-xl border border-ink-200 text-ink-400 hover:border-ink-400 hover:text-ink-700 flex items-center justify-center transition-all">
                    <Share2 size={16} />
                  </button>
                </div>
              </div>

              {/* Price */}
              <div className="flex items-baseline gap-3 mb-4">
                <span className="font-sora font-bold text-3xl price-tag">
                  {formatPrice(listing.price)}
                </span>
              </div>

              {/* Meta */}
              <div className="flex flex-wrap gap-4 pt-4 border-t border-ink-100">
                <div className="flex items-center gap-1.5 text-ink-500 text-sm">
                  <MapPin size={14} className="text-brand-500" />
                  {listing.location}, {listing.city}
                </div>
                <div className="flex items-center gap-1.5 text-ink-500 text-sm">
                  <Clock size={14} className="text-ink-400" />
                  Posted {listing.postedAt}
                </div>
                <div className="flex items-center gap-1.5 text-ink-500 text-sm">
                  <Eye size={14} className="text-ink-400" />
                  {listing.views.toLocaleString()} views
                </div>
              </div>
            </div>

            {/* ─── DESCRIPTION ─── */}
            <div className="bg-white rounded-2xl shadow-card p-6">
              <h2 className="font-sora font-semibold text-ink-900 mb-4">Description</h2>
              <div className="text-ink-600 text-sm leading-relaxed whitespace-pre-line font-jakarta">
                {listing.description}
              </div>
            </div>

            {/* ─── SAFETY TIPS ─── */}
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5">
              <div className="flex gap-3">
                <Shield size={18} className="text-amber-600 mt-0.5 shrink-0" />
                <div>
                  <h3 className="font-sora font-semibold text-amber-800 text-sm mb-2">Stay Safe on Itzem</h3>
                  <ul className="text-amber-700 text-xs space-y-1 font-jakarta">
                    <li>• Never transfer money before seeing the item in person</li>
                    <li>• Meet in a public place for transactions</li>
                    <li>• Verify item condition before paying</li>
                    <li>• Don't share personal banking information</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* ─── RIGHT COLUMN: SELLER ─── */}
          <div className="space-y-5">
            {/* Seller card */}
            <div className="bg-white rounded-2xl shadow-card p-6 sticky top-24">
              <h3 className="font-sora font-semibold text-ink-800 text-sm mb-4">Seller Information</h3>

              {/* Seller profile */}
              <div className="flex items-center gap-3 mb-5 pb-5 border-b border-ink-100">
                <div className="relative">
                  <Image
                    src={listing.seller.avatar}
                    alt={listing.seller.name}
                    width={52}
                    height={52}
                    className="rounded-xl object-cover"
                  />
                  {listing.seller.verified && (
                    <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-brand-500 rounded-full flex items-center justify-center shadow">
                      <CheckCircle size={12} className="text-white" strokeWidth={2.5} />
                    </div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <p className="font-sora font-bold text-ink-900 text-sm truncate">{listing.seller.name}</p>
                  </div>
                  {listing.seller.verified && (
                    <span className="inline-flex items-center gap-1 text-[10px] font-medium text-green-700 bg-green-100 px-2 py-0.5 rounded-full mt-0.5">
                      <CheckCircle size={9} /> Verified
                    </span>
                  )}
                  <p className="text-xs text-ink-400 mt-1 font-jakarta">Member since {listing.seller.memberSince} · {listing.seller.totalAds} ads</p>
                </div>
              </div>

              {/* Contact buttons */}
              <div className="space-y-3">
                {/* WhatsApp */}
                <a
                  href={`https://wa.me/${listing.seller.whatsapp}?text=Hi, I saw your listing "${listing.title}" on Itzem. Is it still available?`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2.5 w-full bg-[#25D366] hover:bg-[#20ba59] text-white font-bold text-sm py-3.5 rounded-xl transition-all shadow-sm hover:shadow-md"
                >
                  <MessageCircle size={18} />
                  Chat on WhatsApp
                </a>

                {/* Call */}
                <a
                  href={`tel:${listing.seller.phone}`}
                  className="flex items-center justify-center gap-2.5 w-full border-2 border-ink-200 hover:border-brand-400 text-ink-700 hover:text-brand-600 font-semibold text-sm py-3 rounded-xl transition-all"
                >
                  <Phone size={16} />
                  {listing.seller.phone}
                </a>

                {/* Show number toggle */}
                <p className="text-center text-xs text-ink-400 font-jakarta">
                  Tap to reveal full number and call directly
                </p>
              </div>

              {/* Report */}
              <button className="flex items-center gap-1.5 text-xs text-ink-400 hover:text-red-500 transition-colors mt-5 mx-auto">
                <Flag size={12} />
                Report this ad
              </button>
            </div>

            {/* Ad ID */}
            <div className="bg-white rounded-2xl shadow-card p-4 text-center">
              <p className="text-xs text-ink-400 font-jakarta">Ad ID: <span className="font-mono text-ink-600">ITZ-{listing.id.padStart(6, '0')}</span></p>
            </div>
          </div>
        </div>

        {/* ─── RELATED LISTINGS ─── */}
        {related.length > 0 && (
          <section className="mt-12">
            <div className="flex items-center justify-between mb-6">
              <h2 className="font-sora font-bold text-xl text-ink-900">Similar Ads</h2>
              <Link href="/listings" className="flex items-center gap-1 text-sm text-brand-500 hover:text-brand-600 font-medium">
                View all <ArrowRight size={14} />
              </Link>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {related.map(l => <ListingCard key={l.id} listing={l} />)}
            </div>
          </section>
        )}
      </div>

      <Footer />
    </main>
  )
}
