'use client'
import { useState } from 'react'
import { SlidersHorizontal, Grid2X2, List, ChevronDown, X, MapPin, Search } from 'lucide-react'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import ListingCard from '@/components/ListingCard'
import { listings, categories, cities } from '@/lib/mockData'

const sortOptions = ['Newest First', 'Price: Low to High', 'Price: High to Low', 'Most Popular']
const conditions = ['New', 'Like New', 'Good', 'Fair']

export default function ListingsPage() {
  const [selectedCategory, setSelectedCategory] = useState('All')
  const [selectedCity, setSelectedCity] = useState('All Cities')
  const [selectedSort, setSelectedSort] = useState('Newest First')
  const [filterOpen, setFilterOpen] = useState(false)
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [selectedConditions, setSelectedConditions] = useState<string[]>([])
  const [priceMin, setPriceMin] = useState('')
  const [priceMax, setPriceMax] = useState('')

  const toggleCondition = (c: string) =>
    setSelectedConditions(prev => prev.includes(c) ? prev.filter(x => x !== c) : [...prev, c])

  const filteredListings = listings.filter(l => {
    if (selectedCategory !== 'All' && l.category !== selectedCategory) return false
    if (selectedCity !== 'All Cities' && l.city !== selectedCity) return false
    if (selectedConditions.length && !selectedConditions.includes(l.condition)) return false
    if (priceMin && l.price < Number(priceMin)) return false
    if (priceMax && l.price > Number(priceMax)) return false
    return true
  })

  const activeFiltersCount = [
    selectedCategory !== 'All',
    selectedCity !== 'All Cities',
    selectedConditions.length > 0,
    priceMin || priceMax,
  ].filter(Boolean).length

  return (
    <main>
      <Navbar />

      {/* ─── PAGE HEADER ─── */}
      <div className="bg-white border-b border-ink-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
          <div className="flex flex-col sm:flex-row sm:items-center gap-3">
            <div className="flex-1">
              <h1 className="font-sora font-bold text-xl text-ink-900">
                {selectedCategory === 'All' ? 'All Listings' : categories.find(c => c.id === selectedCategory)?.name}
              </h1>
              <p className="text-ink-400 text-sm mt-0.5">
                {filteredListings.length} ads found
                {selectedCity !== 'All Cities' ? ` in ${selectedCity}` : ' across Pakistan'}
              </p>
            </div>

            {/* City filter */}
            <div className="flex items-center gap-2 border border-ink-200 rounded-xl px-3 py-2 bg-ink-50 text-sm">
              <MapPin size={14} className="text-brand-500" />
              <select
                value={selectedCity}
                onChange={e => setSelectedCity(e.target.value)}
                className="bg-transparent text-ink-700 outline-none font-jakarta cursor-pointer"
              >
                {cities.map(c => <option key={c}>{c}</option>)}
              </select>
            </div>

            {/* Sort */}
            <div className="flex items-center gap-2 border border-ink-200 rounded-xl px-3 py-2 bg-ink-50 text-sm">
              <select
                value={selectedSort}
                onChange={e => setSelectedSort(e.target.value)}
                className="bg-transparent text-ink-700 outline-none font-jakarta cursor-pointer"
              >
                {sortOptions.map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
          </div>

          {/* Category pills */}
          <div className="flex gap-2 mt-4 overflow-x-auto pb-1 scrollbar-hide">
            <button
              onClick={() => setSelectedCategory('All')}
              className={`shrink-0 px-4 py-1.5 rounded-full text-sm font-medium transition-all ${selectedCategory === 'All' ? 'bg-brand-500 text-white shadow-sm' : 'bg-ink-100 text-ink-600 hover:bg-ink-200'}`}
            >
              All
            </button>
            {categories.map(cat => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`shrink-0 flex items-center gap-1.5 px-4 py-1.5 rounded-full text-sm font-medium transition-all ${selectedCategory === cat.id ? 'bg-brand-500 text-white shadow-sm' : 'bg-ink-100 text-ink-600 hover:bg-ink-200'}`}
              >
                <span>{cat.icon}</span>
                {cat.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ─── MAIN CONTENT ─── */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex gap-6">

          {/* ─── SIDEBAR FILTERS (desktop) ─── */}
          <aside className="hidden lg:block w-64 shrink-0">
            <div className="bg-white rounded-2xl shadow-card overflow-hidden sticky top-24">
              <div className="px-5 py-4 border-b border-ink-100">
                <h3 className="font-sora font-semibold text-ink-900 text-sm flex items-center gap-2">
                  <SlidersHorizontal size={15} className="text-brand-500" />
                  Filters
                  {activeFiltersCount > 0 && (
                    <span className="ml-auto text-xs bg-brand-500 text-white px-2 py-0.5 rounded-full">{activeFiltersCount}</span>
                  )}
                </h3>
              </div>

              {/* Condition */}
              <div className="px-5 py-4 border-b border-ink-100">
                <h4 className="font-semibold text-ink-700 text-xs uppercase tracking-wide mb-3">Condition</h4>
                <div className="space-y-2">
                  {conditions.map(c => (
                    <label key={c} className="flex items-center gap-2 cursor-pointer group">
                      <input
                        type="checkbox"
                        checked={selectedConditions.includes(c)}
                        onChange={() => toggleCondition(c)}
                        className="w-4 h-4 rounded accent-brand-500 cursor-pointer"
                      />
                      <span className="text-sm text-ink-700 group-hover:text-ink-900 font-jakarta">{c}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Price range */}
              <div className="px-5 py-4 border-b border-ink-100">
                <h4 className="font-semibold text-ink-700 text-xs uppercase tracking-wide mb-3">Price (PKR)</h4>
                <div className="flex gap-2">
                  <input
                    type="number"
                    placeholder="Min"
                    value={priceMin}
                    onChange={e => setPriceMin(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-ink-200 rounded-lg outline-none focus:border-brand-400 font-jakarta bg-ink-50"
                  />
                  <input
                    type="number"
                    placeholder="Max"
                    value={priceMax}
                    onChange={e => setPriceMax(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-ink-200 rounded-lg outline-none focus:border-brand-400 font-jakarta bg-ink-50"
                  />
                </div>
              </div>

              {/* City */}
              <div className="px-5 py-4 border-b border-ink-100">
                <h4 className="font-semibold text-ink-700 text-xs uppercase tracking-wide mb-3">City</h4>
                <div className="space-y-1.5">
                  {cities.map(c => (
                    <button
                      key={c}
                      onClick={() => setSelectedCity(c)}
                      className={`w-full text-left text-sm px-3 py-1.5 rounded-lg transition-colors font-jakarta ${selectedCity === c ? 'bg-brand-50 text-brand-600 font-medium' : 'text-ink-600 hover:bg-ink-50'}`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>

              {/* Clear */}
              <div className="px-5 py-4">
                <button
                  onClick={() => {
                    setSelectedCategory('All')
                    setSelectedCity('All Cities')
                    setSelectedConditions([])
                    setPriceMin('')
                    setPriceMax('')
                  }}
                  className="w-full py-2 border border-ink-200 rounded-xl text-xs text-ink-500 hover:text-ink-800 hover:border-ink-400 transition-colors font-medium"
                >
                  Clear All Filters
                </button>
              </div>
            </div>
          </aside>

          {/* ─── LISTINGS GRID ─── */}
          <div className="flex-1 min-w-0">
            {/* Mobile filter toggle */}
            <div className="flex items-center justify-between mb-5 lg:hidden">
              <button
                onClick={() => setFilterOpen(!filterOpen)}
                className="flex items-center gap-2 border border-ink-200 rounded-xl px-4 py-2 text-sm text-ink-700 bg-white shadow-sm"
              >
                <SlidersHorizontal size={15} />
                Filters
                {activeFiltersCount > 0 && <span className="bg-brand-500 text-white text-xs px-1.5 rounded-full">{activeFiltersCount}</span>}
              </button>
              <div className="flex gap-2">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-2 rounded-lg ${viewMode === 'grid' ? 'bg-brand-50 text-brand-500' : 'text-ink-400'}`}
                >
                  <Grid2X2 size={16} />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-2 rounded-lg ${viewMode === 'list' ? 'bg-brand-50 text-brand-500' : 'text-ink-400'}`}
                >
                  <List size={16} />
                </button>
              </div>
            </div>

            {/* Mobile filter panel */}
            {filterOpen && (
              <div className="lg:hidden bg-white rounded-2xl shadow-card p-4 mb-5 border border-ink-100">
                <div className="flex justify-between items-center mb-4">
                  <span className="font-semibold text-ink-800 text-sm">Filters</span>
                  <button onClick={() => setFilterOpen(false)}>
                    <X size={16} className="text-ink-400" />
                  </button>
                </div>
                <div className="space-y-3">
                  <h4 className="text-xs font-semibold text-ink-500 uppercase">Condition</h4>
                  <div className="flex flex-wrap gap-2">
                    {conditions.map(c => (
                      <button
                        key={c}
                        onClick={() => toggleCondition(c)}
                        className={`px-3 py-1 rounded-full text-sm border transition-colors ${selectedConditions.includes(c) ? 'border-brand-500 bg-brand-50 text-brand-600 font-medium' : 'border-ink-200 text-ink-600'}`}
                      >
                        {c}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {filteredListings.length === 0 ? (
              <div className="bg-white rounded-2xl shadow-card p-16 text-center">
                <div className="text-5xl mb-4">🔍</div>
                <h3 className="font-sora font-bold text-ink-800 text-lg mb-2">No ads found</h3>
                <p className="text-ink-400 text-sm">Try adjusting your filters or search terms</p>
                <button
                  onClick={() => {
                    setSelectedCategory('All')
                    setSelectedCity('All Cities')
                    setSelectedConditions([])
                  }}
                  className="mt-5 bg-brand-500 text-white px-6 py-2.5 rounded-xl text-sm font-semibold"
                >
                  Clear Filters
                </button>
              </div>
            ) : (
              <div className={`grid gap-4 ${viewMode === 'grid' ? 'grid-cols-1 sm:grid-cols-2 xl:grid-cols-3' : 'grid-cols-1'}`}>
                {filteredListings.map((listing) => (
                  <ListingCard key={listing.id} listing={listing} />
                ))}
              </div>
            )}

            {/* Load more */}
            {filteredListings.length > 0 && (
              <div className="mt-8 text-center">
                <button className="bg-white border border-ink-200 hover:border-brand-400 text-ink-700 hover:text-brand-600 font-semibold text-sm px-8 py-3 rounded-xl transition-all shadow-sm hover:shadow-card">
                  Load More Ads
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      <Footer />
    </main>
  )
}
