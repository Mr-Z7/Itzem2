import Link from 'next/link'
import Image from 'next/image'
import { Search, MapPin, ChevronDown, ArrowRight, Shield, Clock, Star, TrendingUp } from 'lucide-react'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import ListingCard from '@/components/ListingCard'
import { categories, listings } from '@/lib/mockData'

export default function HomePage() {
  const featuredListings = listings.filter(l => l.featured).slice(0, 6)
  const recentListings = listings.slice(0, 8)

  return (
    <main>
      <Navbar />

      {/* ─── HERO ─── */}
      <section className="hero-gradient relative overflow-hidden">
        {/* Decorative blobs */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-32 -right-32 w-[500px] h-[500px] rounded-full bg-brand-500/10 blur-3xl" />
          <div className="absolute -bottom-20 -left-20 w-[400px] h-[400px] rounded-full bg-blue-500/10 blur-3xl" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] rounded-full bg-brand-600/5 blur-3xl" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
          {/* Trust badge */}
          <div className="flex justify-center mb-6">
            <span className="inline-flex items-center gap-2 bg-white/10 border border-white/20 text-white/80 text-xs font-medium px-4 py-1.5 rounded-full backdrop-blur-sm">
              <span className="w-1.5 h-1.5 bg-green-400 rounded-full pulse-dot" />
              Trusted by 2M+ Pakistanis
            </span>
          </div>

          <h1 className="font-sora text-3xl md:text-5xl lg:text-6xl font-bold text-white text-center mb-4 leading-tight text-balance">
            Buy & Sell Anything
            <br />
            <span className="text-brand-400">Across Pakistan</span>
          </h1>
          <p className="text-center text-ink-300 mb-10 max-w-xl mx-auto font-jakarta text-sm md:text-base">
            From cars and mobiles to property and fashion — find great deals posted by real people near you.
          </p>

          {/* Search box */}
          <div className="max-w-3xl mx-auto">
            <div className="bg-white rounded-2xl p-2 shadow-2xl flex flex-col sm:flex-row gap-2">
              <div className="flex items-center gap-2 border border-ink-200 rounded-xl px-3 py-2 sm:w-44 shrink-0 bg-ink-50">
                <MapPin size={15} className="text-brand-500 shrink-0" />
                <select className="bg-transparent text-sm text-ink-700 outline-none w-full font-jakarta cursor-pointer">
                  <option>All Pakistan</option>
                  <option>Karachi</option>
                  <option>Lahore</option>
                  <option>Islamabad</option>
                  <option>Rawalpindi</option>
                  <option>Peshawar</option>
                </select>
              </div>
              <input
                type="text"
                placeholder="Search for cars, mobiles, property..."
                className="flex-1 px-4 py-2.5 text-sm text-ink-800 outline-none placeholder-ink-400 font-jakarta bg-transparent"
              />
              <Link
                href="/listings"
                className="flex items-center justify-center gap-2 bg-brand-500 hover:bg-brand-600 text-white font-semibold text-sm px-6 py-3 rounded-xl transition-all shadow-md hover:shadow-brand-glow shrink-0"
              >
                <Search size={16} />
                Search
              </Link>
            </div>

            {/* Popular searches */}
            <div className="flex flex-wrap items-center justify-center gap-2 mt-4">
              <span className="text-ink-400 text-xs">Popular:</span>
              {['Toyota Corolla', 'iPhone 15', 'Honda Civic', 'Laptop', '1 Kanal House'].map(term => (
                <Link
                  key={term}
                  href="/listings"
                  className="text-white/70 hover:text-brand-400 text-xs border border-white/20 hover:border-brand-400/50 px-3 py-1 rounded-full transition-colors backdrop-blur-sm"
                >
                  {term}
                </Link>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom wave */}
        <div className="relative h-10 bg-[#fafaf8]">
          <svg viewBox="0 0 1440 40" className="absolute bottom-0 w-full" preserveAspectRatio="none">
            <path fill="#0f131a" d="M0,40 L1440,40 L1440,10 Q720,40 0,10 Z" opacity="0.05" />
          </svg>
        </div>
      </section>

      {/* ─── TRUST STRIP ─── */}
      <section className="bg-white border-b border-ink-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { icon: Shield, label: 'Verified Sellers', sub: 'ID-checked members' },
              { icon: Clock, label: 'Post in 2 Minutes', sub: 'Quick & easy listing' },
              { icon: Star, label: '2M+ Active Ads', sub: 'Something for everyone' },
              { icon: TrendingUp, label: 'Free to Post', sub: 'No hidden fees' },
            ].map(({ icon: Icon, label, sub }) => (
              <div key={label} className="flex items-center gap-3">
                <div className="w-10 h-10 bg-brand-50 rounded-xl flex items-center justify-center shrink-0">
                  <Icon size={18} className="text-brand-500" />
                </div>
                <div>
                  <p className="font-sora font-semibold text-ink-800 text-sm">{label}</p>
                  <p className="text-ink-400 text-xs">{sub}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── CATEGORIES ─── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="font-sora font-bold text-2xl md:text-3xl text-ink-900">Browse by Category</h2>
            <p className="text-ink-400 text-sm mt-1">Find what you need in your area</p>
          </div>
          <Link href="/listings" className="hidden md:flex items-center gap-1 text-sm font-medium text-brand-500 hover:text-brand-600 transition-colors">
            All categories <ArrowRight size={15} />
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-8 gap-3">
          {categories.map((cat) => (
            <Link key={cat.id} href={`/listings?category=${cat.id}`}>
              <div className="category-card bg-white border border-ink-100 rounded-2xl p-4 text-center cursor-pointer hover:border-brand-200 hover:shadow-card-hover group">
                <div className={`w-12 h-12 bg-gradient-to-br ${cat.color} rounded-xl flex items-center justify-center mx-auto mb-3 text-2xl shadow-sm group-hover:scale-105 transition-transform`}>
                  {cat.icon}
                </div>
                <p className="font-sora font-semibold text-xs text-ink-800 leading-tight">{cat.name}</p>
                <p className="text-[10px] text-ink-400 mt-0.5">{cat.count.toLocaleString()} ads</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* ─── FEATURED LISTINGS ─── */}
      <section className="bg-white py-14 border-y border-ink-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <div>
              <span className="inline-flex items-center gap-1.5 bg-brand-50 text-brand-600 text-xs font-bold px-3 py-1 rounded-full mb-2 border border-brand-100">
                ⭐ Featured
              </span>
              <h2 className="font-sora font-bold text-2xl md:text-3xl text-ink-900">Top Picks Today</h2>
            </div>
            <Link href="/listings" className="hidden md:flex items-center gap-1 text-sm font-medium text-brand-500 hover:text-brand-600 transition-colors">
              View all <ArrowRight size={15} />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {featuredListings.map((listing) => (
              <ListingCard key={listing.id} listing={listing} />
            ))}
          </div>
        </div>
      </section>

      {/* ─── RECENT LISTINGS ─── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="font-sora font-bold text-2xl md:text-3xl text-ink-900">Latest Ads</h2>
            <p className="text-ink-400 text-sm mt-1">Fresh listings just posted</p>
          </div>
          <Link href="/listings" className="flex items-center gap-1 text-sm font-medium text-brand-500 hover:text-brand-600 transition-colors">
            View all <ArrowRight size={15} />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {recentListings.map((listing) => (
            <ListingCard key={listing.id} listing={listing} />
          ))}
        </div>
      </section>

      {/* ─── CTA BANNER ─── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-14">
        <div className="hero-gradient rounded-3xl p-8 md:p-12 relative overflow-hidden">
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="absolute -top-20 -right-20 w-64 h-64 rounded-full bg-brand-500/20 blur-3xl" />
            <div className="absolute -bottom-10 -left-10 w-48 h-48 rounded-full bg-blue-500/10 blur-3xl" />
          </div>
          <div className="relative flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h2 className="font-sora font-bold text-2xl md:text-3xl text-white mb-2">
                Got Something to Sell?
              </h2>
              <p className="text-ink-300 text-sm max-w-md">
                Post your ad for free in under 2 minutes. Reach thousands of buyers across Pakistan today.
              </p>
            </div>
            <Link
              href="#"
              className="shrink-0 flex items-center gap-2 bg-brand-500 hover:bg-brand-600 text-white font-bold px-8 py-4 rounded-2xl transition-all shadow-lg hover:shadow-brand-glow text-sm"
            >
              Post a Free Ad
              <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
