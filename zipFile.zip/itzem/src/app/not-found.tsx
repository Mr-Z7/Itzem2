import Link from 'next/link'
import Navbar from '@/components/Navbar'

export default function NotFound() {
  return (
    <main>
      <Navbar />
      <div className="min-h-[60vh] flex flex-col items-center justify-center text-center px-4">
        <div className="text-7xl mb-6">🔍</div>
        <h1 className="font-sora font-bold text-3xl text-ink-900 mb-2">Ad Not Found</h1>
        <p className="text-ink-400 mb-8 max-w-sm">This listing may have been removed or doesn't exist.</p>
        <Link
          href="/listings"
          className="bg-brand-500 hover:bg-brand-600 text-white font-semibold px-8 py-3 rounded-xl transition-all"
        >
          Browse All Ads
        </Link>
      </div>
    </main>
  )
}
