import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Itzem – Buy & Sell Anything in Pakistan',
  description: 'Pakistan\'s trusted marketplace to buy and sell cars, mobiles, property, electronics, and more.',
  keywords: 'buy sell Pakistan, classified ads, OLX Pakistan, cars for sale, mobiles, property',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-[#fafaf8]">
        {children}
      </body>
    </html>
  )
}
